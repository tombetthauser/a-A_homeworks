class GraphNode

    attr_accessor :val, :neighbors

    def initialize(val)
        self.val = val
        self.neighbors = []
    end

end

def bfs(start_node, target_val)
    queue = [start_node]
    visited = Set.new()
    if queue.length > 0
        node = queue.shift
        unless visited.include?(node)
            if node.val == target_val
                return node.val 
            else
                visited.add(node)
                queue += node.neighbors
            end
        end
    end
    nil
end


## ran out of time - had to look at solution - still catching an error in relation to the set
## `bfs': uninitialized constant Set





a = GraphNode.new('a')
b = GraphNode.new('b')
c = GraphNode.new('c')
d = GraphNode.new('d')
e = GraphNode.new('e')
f = GraphNode.new('f')
a.neighbors = [b, c, e]
c.neighbors = [b, d]
e.neighbors = [a]
f.neighbors = [e]


p bfs(a, "b")

# puts a.val
# puts b.val
# puts c.val
# puts d.val
# puts e.val
# puts f.val